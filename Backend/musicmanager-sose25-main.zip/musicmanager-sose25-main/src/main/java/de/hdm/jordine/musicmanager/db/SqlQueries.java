package de.hdm.jordine.musicmanager.db;

import de.hdm.jordine.musicmanager.model.ITrack;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import static de.hdm.jordine.musicmanager.db.DbConstants.*;

class SqlQueries {

    private final static Logger logger = LogManager.getLogger(SqlQueries.class);

    private Connection sqlConnection;
    private static SqlQueries instance;

    SqlQueries(Connection sqlConnection){
        this.sqlConnection = sqlConnection;
    }

    PreparedStatement createAudioTracksTable() throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS " + AUDIOTRACK_TABLE + "("+
                AUDIOTRACK_ID + " INTEGER AUTO_INCREMENT PRIMARY KEY," +
                AUDIOTRACK_TITLE + " TEXT NOT NULL," +
                AUDIOTRACK_ARTIST + " TEXT NOT NULL," +
                AUDIOTRACK_PATH_TO_FILE + " TEXT NOT NULL)";
        logger.debug(sql);
        PreparedStatement stmt = sqlConnection.prepareStatement(sql);

        return stmt;
    }

    PreparedStatement dropAudioTracksTable() throws SQLException {
        String sql = "DROP TABLE IF EXISTS " + AUDIOTRACK_TABLE;
        logger.debug(sql);
        PreparedStatement stmt = sqlConnection.prepareStatement(sql);

        return stmt;
    }

    PreparedStatement insertAudioTrack(ITrack audioTrack) throws SQLException{
        String sql = "INSERT INTO " + AUDIOTRACK_TABLE + "(" +
                AUDIOTRACK_TITLE + ", " +
                AUDIOTRACK_ARTIST + ", " +
                AUDIOTRACK_PATH_TO_FILE + ") " +
                "VALUES(?, ?, ?)" +
                "RETURNING " +  AUDIOTRACK_ID;
        logger.debug(sql);
        PreparedStatement stmt = sqlConnection.prepareStatement(sql);

        stmt.setString(1, audioTrack.getTitle());
        stmt.setString(2, audioTrack.getArtist());
        stmt.setString(3, audioTrack.getPath());

        return stmt;
    }

    PreparedStatement getAudioTracks() throws SQLException{
        String sql = "SELECT " + AUDIOTRACK_ID + ", " +
                AUDIOTRACK_TITLE + ", " +
                AUDIOTRACK_ARTIST + ", " +
                AUDIOTRACK_PATH_TO_FILE + " " +
                "FROM " + AUDIOTRACK_TABLE;
        logger.debug(sql);
        PreparedStatement stmt = sqlConnection.prepareStatement(sql);

        return stmt;
    }

    PreparedStatement getAudioTrack(int dbId) throws SQLException{
        String sql = "SELECT " + AUDIOTRACK_ID + ", " +
                AUDIOTRACK_TITLE + ", " +
                AUDIOTRACK_ARTIST + ", " +
                AUDIOTRACK_PATH_TO_FILE + " " +
                "FROM " + AUDIOTRACK_TABLE + " " +
                "WHERE id = ?";
        logger.debug(sql);
        PreparedStatement stmt = sqlConnection.prepareStatement(sql);
        stmt.setInt(1, dbId);

        return stmt;
    }

    PreparedStatement getAudioTrackByTitle(String title) throws SQLException{
        String sql = "SELECT " + AUDIOTRACK_ID + ", " +
                AUDIOTRACK_TITLE + ", " +
                AUDIOTRACK_ARTIST + ", " +
                AUDIOTRACK_PATH_TO_FILE + " " +
                "FROM " + AUDIOTRACK_TABLE + " " +
                "WHERE " + AUDIOTRACK_TITLE + " = ?";
        logger.debug(sql);
        PreparedStatement stmt = sqlConnection.prepareStatement(sql);
        stmt.setString(1, title);

        return stmt;
    }

    PreparedStatement updateAudioTrack(ITrack audioTrack) throws SQLException{
        String sql = "UPDATE " + AUDIOTRACK_TABLE + " SET " +
                AUDIOTRACK_TITLE + " = ?, " +
                AUDIOTRACK_ARTIST + " = ?, " +
                AUDIOTRACK_PATH_TO_FILE +" = ? " +
                "WHERE " + AUDIOTRACK_ID + " = ?";
        logger.debug(sql);
        PreparedStatement stmt = sqlConnection.prepareStatement(sql);
        stmt.setString(1, audioTrack.getTitle());
        stmt.setString(2, audioTrack.getArtist());
        stmt.setString(3, audioTrack.getPath());
        stmt.setInt(4, audioTrack.getDbId());

        return stmt;
    }

    PreparedStatement deleteAudioTrack(ITrack audioTrack) throws SQLException{
        String sql = "DELETE FROM " + AUDIOTRACK_TABLE + " WHERE id = ?";
        logger.debug(sql);
        PreparedStatement stmt = sqlConnection.prepareStatement(sql);
        stmt.setInt(1, audioTrack.getDbId());

        return stmt;
    }

    PreparedStatement deleteAllAudioTracks() throws SQLException{
        String sql = "DELETE FROM " + AUDIOTRACK_TABLE;
        logger.debug(sql);
        PreparedStatement stmt = sqlConnection.prepareStatement(sql);

        return stmt;
    }

}
