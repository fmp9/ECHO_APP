package de.hdm.jordine.musicmanager.model;

/**
 * Interface representing a track.
 */
public interface ITrack {

    /**
     * Gets the title of the track.
     *
     * @return the title of the track
     */
    String getTitle();

    /**
     * Gets the artist of the track.
     *
     * @return the artist of the track
     */
    String getArtist();

    /**
     * Gets the file path of the track.
     *
     * @return the file path of the track
     */
    String getPath();

    /**
     * Checks if the track is marked as favorite.
     *
     * @return true if the track is favorite, false otherwise
     */
    boolean isFavorite();

    /**
     * Sets the database ID of the track.
     *
     * @param id the database ID to set
     */
    void setDbId(int id);

    /**
     * Gets the database ID of the track.
     *
     * @return the database ID of the track
     */
    int getDbId();

    /**
     * Plays the track.
     */
    void play();

    /**
     * Returns a string representation of the track.
     *
     * @return a string representation of the track
     */
    @Override
    String toString();
}
