package de.hdm.jordine.musicmanager.api;

import de.hdm.jordine.musicmanager.controller.MusicLibrary;
import de.hdm.jordine.musicmanager.model.ITrack;
import de.hdm.jordine.musicmanager.model.TrackFactory;
import de.hdm.jordine.musicmanager.model.TrackType;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Collection;
import java.util.Map;

@RestController
@RequestMapping("/api/v1")
public class AudioTrackApiController {

    private final MusicLibrary musicLibrary;

    @Autowired
    public AudioTrackApiController(MusicLibrary musicLibrary) {
        this.musicLibrary = musicLibrary;
    }


    @GetMapping("/audiotrack")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponses(@ApiResponse(responseCode = "404", description = "id not found", content = @Content))
    public ITrack getAudioTrack(@RequestParam(value = "id") int id){
        try {
            return musicLibrary.getTrack(id);
        }catch (IllegalArgumentException e){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Id not found: " + id, e);
        }

    }

    @GetMapping("/audiotrackByTitle")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponses(@ApiResponse(responseCode = "404", description = "title not found", content = @Content))
    public ITrack getAudioTrackByTitle(@RequestParam(value = "title") String title){
        try {
            return musicLibrary.getTrack(title);
        }catch (IllegalArgumentException e){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Title not found: " + title, e);
        }
    }

    @GetMapping("/audiotracks")
    @ResponseStatus(HttpStatus.OK)
    public Collection<ITrack> getAudioTracks(){
        return musicLibrary.getLibrary();
    }

    @PostMapping("/audiotrack")
    @ResponseStatus(HttpStatus.CREATED)
    public ITrack postAudioTrack(@RequestBody Map<String, String> audioTrackMap){

        musicLibrary.addTrack(
                audioTrackMap.get("title"),
                audioTrackMap.get("artist"),
                audioTrackMap.get("path")
        );

        return musicLibrary.getTrack(audioTrackMap.get("title"));
    }

    @PutMapping("/audiotrack")
    @ResponseStatus(HttpStatus.OK)
    public ITrack putAudioTrack(@RequestBody Map<String, String> audioTrackMap){
        ITrack updateTrackOld = musicLibrary.getTrack(
                Integer.parseInt(audioTrackMap.get("dbId")));

        ITrack updateTrackNew = TrackFactory.createTrackInstance(
                TrackType.DEFAULT,
                audioTrackMap.get("title"),
                audioTrackMap.get("artist"),
                audioTrackMap.get("path")
        );

        updateTrackNew.setDbId(updateTrackOld.getDbId());
        musicLibrary.updateTrack(updateTrackNew);

        return musicLibrary.getTrack(updateTrackNew.getDbId());
    }

    @DeleteMapping("/audiotrack")
    @ResponseStatus(HttpStatus.OK)
    public ITrack deleteAudioTrack(@RequestParam(value = "title") String title){
        ITrack trackToBeDeleted = musicLibrary.getTrack(title);

        musicLibrary.deleteTrack(trackToBeDeleted);

        return trackToBeDeleted;
    }

}
