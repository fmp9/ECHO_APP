package de.hdm.jordine.musicmanager.db;

public class DbManagerFactory {

    public static IDbManager getInstance(DbType dbType){
        if (dbType == DbType.SQL){
            return SqlDbManager.getInstance();
        } else if (dbType == DbType.NoSQL) {
            return NoSqlManager.getInstance();
        }

        throw new IllegalArgumentException("Unsupported db type: " + dbType);
    }

}
