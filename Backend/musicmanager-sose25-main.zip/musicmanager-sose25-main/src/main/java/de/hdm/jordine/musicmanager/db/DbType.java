package de.hdm.jordine.musicmanager.db;

public enum DbType {
    SQL,
    NoSQL
}
