package de.hdm.jordine.musicmanager.exception;

/**
 * Exception thrown when an invalid track is encountered.
 */
public class InvalidTrackException extends RuntimeException {
    /**
     * Constructs a new InvalidTrackException with the specified detail message.
     *
     * @param message the detail message
     */
    public InvalidTrackException(String message) {
        super(message);
    }
}
