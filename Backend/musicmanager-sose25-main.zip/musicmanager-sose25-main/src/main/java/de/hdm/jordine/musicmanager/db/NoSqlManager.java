package de.hdm.jordine.musicmanager.db;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import de.hdm.jordine.musicmanager.exception.InvalidTrackException;
import de.hdm.jordine.musicmanager.model.ITrack;
import de.hdm.jordine.musicmanager.model.TrackFactory;
import de.hdm.jordine.musicmanager.model.TrackType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.set;
import static de.hdm.jordine.musicmanager.db.DbConstants.*;

public class NoSqlManager implements IDbManager{

    private static final Logger logger = LogManager.getLogger(NoSqlManager.class);

    private final AtomicInteger audioTrackIdGenerator;
    private static NoSqlManager instance;

    private NoSqlManager(){
        audioTrackIdGenerator = new AtomicInteger();
    }

    public static NoSqlManager getInstance(){
        if (instance == null){
            instance = new NoSqlManager();
        }
        return instance;
    }

    private MongoClient getMongoClient(){
        // Simplified approach to create a MongoDB client
        // This uses the simpler create() method with just a connection string
        // which is less likely to cause version compatibility issues
        String connectionString = "mongodb://musicmanageruser:sup3r_s4ve_pwd@localhost:27017";
        return MongoClients.create(connectionString);
    }

    private MongoCollection<Document> getAudioTrackCollection(MongoClient client){
        MongoDatabase database = client.getDatabase("musicmanagerDatabase");
        return database.getCollection(AUDIOTRACK_COLLECTION);
    }

    @Override
    public ITrack insertAudioTrack(ITrack audioTrack) {
        try(MongoClient client = getMongoClient()) {

            Integer trackId = audioTrackIdGenerator.incrementAndGet();
            Document track = new Document("_id", new ObjectId());
            track.append(AUDIOTRACK_ID, trackId)
                    .append(AUDIOTRACK_TITLE, audioTrack.getTitle())
                    .append(AUDIOTRACK_ARTIST, audioTrack.getArtist())
                    .append(AUDIOTRACK_PATH_TO_FILE, audioTrack.getPath());

            audioTrack.setDbId(trackId);

            getAudioTrackCollection(client).insertOne(track);

            logger.debug("inserted: " + track);
            return audioTrack;
        }catch (Exception e) {
            logger.error(e);
            throw new InvalidTrackException("Could not insert track: " + audioTrack);
        }
    }

    @Override
    public Map<String, ITrack> getAudioTracks() {
        Map<String, ITrack> audioTracks = new HashMap<>();

        try(MongoClient client = getMongoClient()) {
            List<Document> results = getAudioTrackCollection(client).find().into(new LinkedList<>());
            for (Document result : results){
                ITrack entry = TrackFactory.createTrackInstance(
                        TrackType.DEFAULT,
                        result.getString(AUDIOTRACK_TITLE),
                        result.getString(AUDIOTRACK_ARTIST),
                        result.getString(AUDIOTRACK_PATH_TO_FILE));
                entry.setDbId(result.getInteger(AUDIOTRACK_ID));
                audioTracks.put(entry.getTitle(), entry);
            }
        }
        logger.debug("received: " + audioTracks);

        return audioTracks;
    }

    @Override
    public ITrack getAudioTrack(int dbId) {
        ITrack entry;
        try(MongoClient client = getMongoClient()) {
            Document result = getAudioTrackCollection(client).find(eq(AUDIOTRACK_ID, dbId)).first();
            if (result == null){
                throw new IllegalArgumentException("Id not found: " + dbId);
            }
            entry = TrackFactory.createTrackInstance(
                    TrackType.DEFAULT,
                    result.getString(AUDIOTRACK_TITLE),
                    result.getString(AUDIOTRACK_ARTIST),
                    result.getString(AUDIOTRACK_PATH_TO_FILE));
            entry.setDbId(result.getInteger(AUDIOTRACK_ID));
        }
        logger.debug("received: " + entry);

        return entry;
    }

    @Override
    public ITrack getAudioTrackByTitle(String title) {
        ITrack entry = null;
        try(MongoClient client = getMongoClient()) {
            Document result = getAudioTrackCollection(client).find(eq(AUDIOTRACK_TITLE, title)).first();
            if (result == null){
                throw new IllegalArgumentException("Title not found: " + title);
            }
            entry = TrackFactory.createTrackInstance(
                    TrackType.DEFAULT,
                    result.getString(AUDIOTRACK_TITLE),
                    result.getString(AUDIOTRACK_ARTIST),
                    result.getString(AUDIOTRACK_PATH_TO_FILE));
            entry.setDbId(result.getInteger(AUDIOTRACK_ID));
        }
        logger.debug("received: " + entry);

        return entry;
    }

    @Override
    public ITrack updateAudioTrack(ITrack audioTrack) {
        try(MongoClient client = getMongoClient()) {
            Bson filter = eq(AUDIOTRACK_ID, audioTrack.getDbId());

            List<Bson> updateOperations = new LinkedList<>();
            updateOperations.add(set(AUDIOTRACK_TITLE, audioTrack.getTitle()));
            updateOperations.add(set(AUDIOTRACK_ARTIST, audioTrack.getArtist()));
            updateOperations.add(set(AUDIOTRACK_PATH_TO_FILE, audioTrack.getPath()));

            getAudioTrackCollection(client).updateOne(filter, updateOperations);

            logger.debug("updated: " + audioTrack);
            return audioTrack;
        } catch (Exception e) {
            logger.error(e);
            throw new InvalidTrackException("Could not update track: " + audioTrack);
        }

    }

    @Override
    public ITrack deleteAudioTrack(ITrack audioTrack) {
        try(MongoClient client = getMongoClient()) {
            Bson filter = eq(AUDIOTRACK_ID, audioTrack.getDbId());

            getAudioTrackCollection(client).deleteMany(filter);

            logger.debug("deleted: " + audioTrack);
            return audioTrack;
        }catch (Exception e){
            logger.error(e);
            throw new InvalidTrackException("Could not delete track: " + audioTrack);
        }
    }

    @Override
    public void clearLibrary() {
        try(MongoClient client = getMongoClient()) {
            getAudioTrackCollection(client).deleteMany(new Document());
        }catch (Exception e){
            logger.error(e);
            throw new RuntimeException("Could not clear library");
        }
    }

}