package de.hdm.jordine.musicmanager.model;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

class AudioTrackDefault implements ITrack {

    private final String title;
    private final String artist;
    private final String path;
    private final boolean isFavorite;

    private int dbId;

    private static Logger logger = LogManager.getLogger(AudioTrackDefault.class);

    public AudioTrackDefault(String title, String artist, String path, boolean isFavorite) {
        this.title = title;
        this.artist = artist;
        this.path = path;
        this.isFavorite = isFavorite;
    }

    @Override
    public String getTitle() {
        return title;
    }

    @Override
    public String getArtist() {
        return artist;
    }

    @Override
    public String getPath() {
        return path;
    }

    @Override
    public boolean isFavorite() {
        return isFavorite;
    }

    @Override
    public void setDbId(int dbId) {
        this.dbId = dbId;
    }

    @Override
    public int getDbId() {
        return dbId;
    }

    @Override
    public void play() {
        logger.info("Playing track: " + title + " by " + artist);
    }

    @Override
    public String toString() {
        return "AudioTrack{" +
                "title='" + title + '\'' +
                ", artist='" + artist + '\'' +
                ", path='" + path + '\'' +
                ", isFavorite=" + isFavorite +
                ", dbId=" + dbId +
                '}';
    }
}
