package de.hdm.jordine.musicmanager.db;

import de.hdm.jordine.musicmanager.exception.InvalidTrackException;
import de.hdm.jordine.musicmanager.model.ITrack;
import de.hdm.jordine.musicmanager.model.TrackFactory;
import de.hdm.jordine.musicmanager.model.TrackType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

import static de.hdm.jordine.musicmanager.db.DbConstants.*;

public class SqlDbManager implements IDbManager{

    private final static Logger logger = LogManager.getLogger(SqlDbManager.class);

    private static SqlDbManager instance;
    private final String dbUrl;
    private final String dbUser;
    private final String dbPwd;

    private SqlDbManager(){
        instance = this;
        dbUrl = "jdbc:mariadb://localhost:3306/musicmanagerdb";
        dbUser = "musicmanageruser";
        dbPwd = "sup3r_s4ve_pwd";

        createTables();
    }

    public static SqlDbManager getInstance(){
        if (instance == null){
            instance = new SqlDbManager();
        }
        return instance;
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(dbUrl, dbUser, dbPwd);
    }

    private ITrack getAudioTrackFromResultSet(ResultSet resultSet) throws SQLException {
        int dbId = resultSet.getInt(AUDIOTRACK_ID);
        String title = resultSet.getString(AUDIOTRACK_TITLE);
        String artist = resultSet.getString(AUDIOTRACK_ARTIST);
        String path = resultSet.getString(AUDIOTRACK_PATH_TO_FILE);

        ITrack entry = TrackFactory.createTrackInstance(TrackType.DEFAULT, title, artist, path);
        entry.setDbId(dbId);
        return entry;
    }

    public void createTables(){
        try(Connection conn = getConnection()) {
            SqlQueries queries = new SqlQueries(conn);

            PreparedStatement audioTracksTableStmt = queries.createAudioTracksTable();
            audioTracksTableStmt.execute();
        } catch (SQLException e){
            logger.error(e);
        }
    }

    public void dropAudiotracksTable(){
        try(Connection conn = getConnection()) {
            SqlQueries queries = new SqlQueries(conn);
            PreparedStatement stmt = queries.dropAudioTracksTable();
            stmt.execute();
        } catch (SQLException e){
            logger.error(e);
        }
    }

    public ITrack insertAudioTrack(ITrack audioTrack){
        try(Connection conn = getConnection()) {
            SqlQueries queries = new SqlQueries(conn);
            PreparedStatement stmt = queries.insertAudioTrack(audioTrack);
            ResultSet resultSet= stmt.executeQuery();
            if (resultSet.next()){
                audioTrack.setDbId(resultSet.getInt("id"));
            }
            return audioTrack;
        } catch (SQLException e){
            logger.error(e);
            throw new InvalidTrackException("Could not insert track: " + audioTrack);
        }
    }

    public Map<String, ITrack> getAudioTracks(){
        Map<String, ITrack> dbEntries = new HashMap<>();
        try(Connection conn = getConnection()) {
            SqlQueries queries = new SqlQueries(conn);
            PreparedStatement stmt = queries.getAudioTracks();

            ResultSet resultSet = stmt.executeQuery();
            while (resultSet.next()){
                ITrack entry = getAudioTrackFromResultSet(resultSet);
                dbEntries.put(entry.getTitle(), entry);
            }
        } catch (SQLException e){
            logger.error(e);
        }
        return dbEntries;
    }

    public ITrack getAudioTrack(int dbId){
        ITrack entry = null;

        try(Connection conn = getConnection()) {
            SqlQueries queries = new SqlQueries(conn);
            PreparedStatement stmt = queries.getAudioTrack(dbId);
            ResultSet resultSet = stmt.executeQuery();
            if (resultSet.next()) {
                entry = getAudioTrackFromResultSet(resultSet);
            } else {
                throw new IllegalArgumentException("id not found: " + dbId);
            }

        }catch (SQLException e){
            logger.error(e);
        }

        return entry;
    }

    public ITrack getAudioTrackByTitle(String title){
        ITrack entry = null;

        try(Connection conn = getConnection()) {
            SqlQueries queries = new SqlQueries(conn);
            PreparedStatement stmt = queries.getAudioTrackByTitle(title);
            ResultSet resultSet = stmt.executeQuery();
            if (resultSet.next()) {
                entry = getAudioTrackFromResultSet(resultSet);
            } else {
                throw new IllegalArgumentException("Title not found: " + title);
            }

        }catch (SQLException e){
            logger.error(e);
        }

        return entry;
    }

    public ITrack updateAudioTrack(ITrack audioTrack){

        try(Connection conn = getConnection()) {
            SqlQueries queries = new SqlQueries(conn);
            PreparedStatement stmt = queries.updateAudioTrack(audioTrack);
            stmt.execute();
            return audioTrack;
        }catch (SQLException e){
            logger.error(e);
            throw new InvalidTrackException("Could not update track: " + audioTrack);
        }
    }

    public ITrack deleteAudioTrack(ITrack audioTrack){
        try(Connection conn = getConnection()) {
            SqlQueries queries = new SqlQueries(conn);
            PreparedStatement stmt = queries.deleteAudioTrack(audioTrack);
            stmt.execute();
            return audioTrack;
        } catch (SQLException e){
            logger.error(e);
            throw new InvalidTrackException("Could not delete track: " + audioTrack);
        }
    }

    @Override
    public void clearLibrary() {
        try(Connection conn = getConnection()) {
            SqlQueries queries = new SqlQueries(conn);
            PreparedStatement stmt = queries.deleteAllAudioTracks();
            stmt.execute();
        } catch (SQLException e){
            logger.error(e);
            throw new RuntimeException("Could not clear library");
        }
    }

}
