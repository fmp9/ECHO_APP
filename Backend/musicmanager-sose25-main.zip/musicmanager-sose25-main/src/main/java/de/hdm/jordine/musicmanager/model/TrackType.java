package de.hdm.jordine.musicmanager.model;

/**
 * Enum representing the different types of tracks.
 */
public enum TrackType {

    DEFAULT

}