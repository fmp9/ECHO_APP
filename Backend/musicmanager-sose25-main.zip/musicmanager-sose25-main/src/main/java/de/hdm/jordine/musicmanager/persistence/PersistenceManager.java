package de.hdm.jordine.musicmanager.persistence;

import de.hdm.jordine.musicmanager.db.DbManagerFactory;
import de.hdm.jordine.musicmanager.db.DbType;
import de.hdm.jordine.musicmanager.db.IDbManager;
import de.hdm.jordine.musicmanager.model.ITrack;
import org.springframework.stereotype.Repository;

import java.util.Map;


/**
 * The PersistenceManager repository provides methods to manage audio tracks in the database.
 * It uses an instance of IDbManager to perform database operations.
 */
@Repository
public class PersistenceManager {

    private static PersistenceManager instance;
    private IDbManager dbManager;

    /**
     * Private constructor to initialize the PersistenceManager with a SQL or NoSQL database manager.
     */
    public PersistenceManager(){
        dbManager = DbManagerFactory.getInstance(DbType.SQL);
    }

    /**
     * Inserts an audio track into the database.
     *
     * @param audioTrack the audio track to be inserted
     * @return the inserted audio track
     */
    public ITrack insertAudioTrack(ITrack audioTrack){
        return dbManager.insertAudioTrack(audioTrack);
    }

    /**
     * Retrieves all audio tracks from the database.
     *
     * @return a map of audio tracks with their titles as keys
     */
    public Map<String, ITrack> getAudioTracks(){
        return dbManager.getAudioTracks();
    }

    /**
     * Retrieves an audio track from the database by its ID.
     *
     * @param dbId the ID of the audio track
     * @return the audio track with the specified ID
     */
    public ITrack getAudioTrack(int dbId){
        return dbManager.getAudioTrack(dbId);
    }

    /**
     * Retrieves an audio track from the database by its title.
     *
     * @param title the title of the audio track
     * @return the audio track with the specified title
     */
    public ITrack getAudioTrackByTitle(String title){
        return dbManager.getAudioTrackByTitle(title);
    }

    /**
     * Updates an existing audio track in the database.
     *
     * @param audioTrack the audio track with updated information
     * @return the updated audio track
     */
    public ITrack updateAudioTrack(ITrack audioTrack){
        return dbManager.updateAudioTrack(audioTrack);
    }

    /**
     * Deletes an audio track from the database.
     *
     * @param audioTrack the audio track to be deleted
     * @return the deleted audio track
     */
    public ITrack deleteAudioTrack(ITrack audioTrack){
        return dbManager.deleteAudioTrack(audioTrack);
    }

    /**
     * Deletes all audio tracks from the database.
     */
    public void clearLibrary(){
        dbManager.clearLibrary();
    }

}