package de.hdm.jordine.musicmanager.model;

import de.hdm.jordine.musicmanager.exception.InvalidTrackException;

/**
 * Factory class for creating instances of {@link ITrack}.
 */
public class TrackFactory {

    /**
     * Creates an instance of {@link ITrack} based on the specified {@link TrackType}.
     *
     * @param type   the type of the track
     * @param title  the title of the track
     * @param artist the artist of the track
     * @param path   the file path of the track
     * @return an instance of {@link ITrack}
     * @throws InvalidTrackException if the specified track type is unknown
     */
    public static ITrack createTrackInstance(TrackType type, String title, String artist, String path) {
        if (type == TrackType.DEFAULT) {
            return new AudioTrackDefault(title, artist, path, false);
        } else {
            throw new InvalidTrackException("Unknown track type: " + type);
        }
    }
}
