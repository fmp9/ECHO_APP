package de.hdm.jordine.musicmanager.db;

import de.hdm.jordine.musicmanager.model.ITrack;

import java.util.Map;

public interface IDbManager {

    /**
     * Inserts an audio track into the database.
     *
     * @param audioTrack the audio track to be inserted
     * @return the inserted audio track
     */
    ITrack insertAudioTrack(ITrack audioTrack);

    /**
     * Retrieves all audio tracks from the database.
     *
     * @return a map of audio tracks with their titles as keys
     */
    Map<String, ITrack> getAudioTracks();

    /**
     * Retrieves an audio track from the database by its ID.
     *
     * @param dbId the ID of the audio track
     * @return the audio track with the specified ID
     */
    ITrack getAudioTrack(int dbId);

    /**
     * Retrieves an audio track from the database by its title.
     *
     * @param title the title of the audio track
     * @return the audio track with the specified title
     */
    ITrack getAudioTrackByTitle(String title);

    /**
     * Updates an audio track in the database.
     *
     * @param audioTrack the audio track to be updated
     * @return the updated audio track
     */
    ITrack updateAudioTrack(ITrack audioTrack);

    /**
     * Deletes an audio track from the database.
     *
     * @param audioTrack the audio track to be deleted
     * @return the deleted audio track
     */
    ITrack deleteAudioTrack(ITrack audioTrack);

    /**
     * Deletes all audio tracks from the database.
     */
    void clearLibrary();

}
