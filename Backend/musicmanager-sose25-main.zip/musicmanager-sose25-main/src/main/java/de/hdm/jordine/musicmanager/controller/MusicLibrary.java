package de.hdm.jordine.musicmanager.controller;

import de.hdm.jordine.musicmanager.model.ITrack;
import de.hdm.jordine.musicmanager.model.TrackFactory;
import de.hdm.jordine.musicmanager.model.TrackType;
import de.hdm.jordine.musicmanager.persistence.PersistenceManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * The MusicLibrary class is a singleton/component that manages a collection of music tracks.
 * It provides methods to add, retrieve, update, and delete tracks from the library.
 */
@Service
public class MusicLibrary {

    private final PersistenceManager persistenceManager;

    @Autowired
    public MusicLibrary(PersistenceManager persistenceManager){
        this.persistenceManager = persistenceManager;
    }

    /**
     * Adds a track to the library.
     *
     * @param title  the title of the track
     * @param artist the artist of the track
     * @param path   the file path of the track
     * @return the track that was added to the library
     */
    public ITrack addTrack(String title, String artist, String path){
        return persistenceManager.insertAudioTrack(
                TrackFactory.createTrackInstance(TrackType.DEFAULT, title, artist, path)
        );
    }

    /**
     * Retrieves a track from the library by its title.
     *
     * @param title the title of the track
     * @return the track with the specified title, or null if not found
     */
    public ITrack getTrack(String title){
        return persistenceManager.getAudioTrackByTitle(title);
    }

    /**
     * Retrieves all tracks in the library.
     *
     * @return a collection of all tracks in the library
     */
    public Collection<ITrack> getLibrary(){
        return persistenceManager.getAudioTracks().values();
    }

    /**
     * Retrieves a track from the library by its database ID.
     *
     * @param id the database ID of the track
     * @return the track with the specified ID
     */
    public ITrack getTrack(int id) {
        return persistenceManager.getAudioTrack(id);
    }

    /**
     * Updates a track in the library.
     *
     * @param track the track to update
     * @return the previous track associated with the title, or null if there was no mapping for the title
     */
    public ITrack updateTrack(ITrack track){
        return persistenceManager.updateAudioTrack(track);
    }

    /**
     * Deletes a track from the library.
     *
     * @param track the track to delete
     * @return the removed track, or null if there was no mapping for the title
     */
    public ITrack deleteTrack(ITrack track){
        return persistenceManager.deleteAudioTrack(track);
    }

    /**
     * Retrieves a random track from the library.
     *
     * @return a random track from the library
     */
    public ITrack getRandomTrack() {
        List<ITrack> trackList = new LinkedList<>(persistenceManager.getAudioTracks().values());
        int randomIndex = (int) (Math.random() * trackList.size());

        return trackList.get(randomIndex);
    }

    /**
     * Clears all tracks from the library.
     */
    public void clearLibrary() {
        persistenceManager.clearLibrary();
    }

}