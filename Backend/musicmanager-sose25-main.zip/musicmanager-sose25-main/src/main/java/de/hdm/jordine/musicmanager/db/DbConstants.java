package de.hdm.jordine.musicmanager.db;

class DbConstants {

    // Table/collection names
    public static final String AUDIOTRACK_TABLE = "audiotrack";
    public static final String AUDIOTRACK_COLLECTION = "audiotracks";

    // Field names
    public static final String AUDIOTRACK_ID = "id";
    public static final String AUDIOTRACK_TITLE = "title";
    public static final String AUDIOTRACK_ARTIST = "artist";
    public static final String AUDIOTRACK_PATH_TO_FILE = "pathToAudioFile";

}
