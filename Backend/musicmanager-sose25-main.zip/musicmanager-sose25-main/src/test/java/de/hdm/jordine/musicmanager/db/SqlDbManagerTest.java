package de.hdm.jordine.musicmanager.db;

import de.hdm.jordine.musicmanager.model.ITrack;
import de.hdm.jordine.musicmanager.model.TrackFactory;
import de.hdm.jordine.musicmanager.model.TrackType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class SqlDbManagerTest {

    private final String TEST_TITLE = "test_title";
    private final String TEST_ARTIST = "test_artist";
    private final String TEST_PATH = "test_path";

    private final String TEST_UPDATE_TITLE = "test_update_title";
    private final String TEST_UPDATE_ARTIST = "test_update_artist";
    private final String TEST_UPDATE_PATH = "test_update_path";

    @BeforeAll
    static void setUp() {
        SqlDbManager.getInstance().createTables();
    }

    @Test
    void getInstance() {
        assertNotEquals(null, SqlDbManager.getInstance());
    }

    @Test
    void insertAudioTrack() {
        ITrack track = TrackFactory.createTrackInstance(TrackType.DEFAULT, TEST_TITLE, TEST_ARTIST, TEST_PATH);

        assertEquals(0, track.getDbId());
        SqlDbManager.getInstance().insertAudioTrack(track);
        assertTrue(track.getDbId() > 0);

        SqlDbManager.getInstance().deleteAudioTrack(track);
    }

    @Test
    void getAudioTracks() {
        ITrack track = TrackFactory.createTrackInstance(TrackType.DEFAULT, TEST_TITLE, TEST_ARTIST, TEST_PATH);

        SqlDbManager.getInstance().insertAudioTrack(track);
        assertFalse(SqlDbManager.getInstance().getAudioTracks().isEmpty());

        SqlDbManager.getInstance().deleteAudioTrack(track);
    }

    @Test
    void getAudioTrack() {
        ITrack track = TrackFactory.createTrackInstance(TrackType.DEFAULT, TEST_TITLE, TEST_ARTIST, TEST_PATH);

        SqlDbManager.getInstance().insertAudioTrack(track);
        ITrack received = SqlDbManager.getInstance().getAudioTrack(track.getDbId());
        assertEquals(track.getTitle(), received.getTitle());
        assertEquals(track.getArtist(), received.getArtist());
        assertEquals(track.getPath(), received.getPath());

        SqlDbManager.getInstance().deleteAudioTrack(track);
    }

    @Test
    void updateAudioTrack() {
        ITrack track = TrackFactory.createTrackInstance(TrackType.DEFAULT, TEST_TITLE, TEST_ARTIST, TEST_PATH);
        SqlDbManager.getInstance().insertAudioTrack(track);

        ITrack updatedTrack = TrackFactory.createTrackInstance(TrackType.DEFAULT, TEST_UPDATE_TITLE, TEST_UPDATE_ARTIST,
                TEST_UPDATE_PATH);
        assertTrue(track.getDbId() > 0);
        updatedTrack.setDbId(track.getDbId());

        SqlDbManager.getInstance().updateAudioTrack(updatedTrack);

        ITrack received = SqlDbManager.getInstance().getAudioTrack(track.getDbId());

        assertEquals(TEST_UPDATE_TITLE, received.getTitle());
        assertEquals(TEST_UPDATE_ARTIST, received.getArtist());
        assertEquals(TEST_UPDATE_PATH, received.getPath());

        SqlDbManager.getInstance().deleteAudioTrack(received);

    }

    @Test
    void deleteAudioTrack() {
        ITrack track = TrackFactory.createTrackInstance(TrackType.DEFAULT, TEST_TITLE, TEST_ARTIST, TEST_PATH);
        SqlDbManager.getInstance().insertAudioTrack(track);

        SqlDbManager.getInstance().deleteAudioTrack(track);

        assertThrows(IllegalArgumentException.class, () -> SqlDbManager.getInstance().getAudioTrack(track.getDbId()));
    }

}
