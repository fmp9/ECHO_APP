package de.hdm.jordine.musicmanager.api;


import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class AudioTrackApiControllerTest {

    // Tutorial: https://spring.io/guides/gs/testing-web/
    // Tutorial that includes json handling: https://www.javaguides.net/2022/03/spring-boot-unit-testing-crud-rest-api-with-junit-and-mockito.html

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    private final String TEST_TITLE = "test_title";
    private final String TEST_ARTIST = "test_artist";
    private final String TEST_PATH = "test_path";

    @Disabled
    public void getAudioTrack() throws Exception {
        mockMvc.perform(get("/api/v1/audiotrack?id=12")) //very bad! why?
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title", is("14 Passenger")))
                .andExpect(jsonPath("$.artist", is("Reezy")))
                .andExpect(jsonPath("$.path", is("music/14_passenger.mp3")));
    }

    @Test
    public void insertAudioTrack() throws Exception {
        Map<String, String> testTrack = new HashMap<>(); // can be replaced by actual ITrack objects
        testTrack.put("title", TEST_TITLE);
        testTrack.put("artist", TEST_ARTIST);
        testTrack.put("path", TEST_PATH);

        ResultActions result = mockMvc.perform(post("/api/v1/audiotrack")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testTrack)));

        result.andDo(print())
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.title", is(TEST_TITLE)))
                .andExpect(jsonPath("$.artist", is(TEST_ARTIST)))
                .andExpect(jsonPath("$.path", is(TEST_PATH)));

        String title = jsonPath("$.title").toString();
        mockMvc.perform(delete("/api/v1/audiotrack")
                .param("title", TEST_TITLE)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }


}
