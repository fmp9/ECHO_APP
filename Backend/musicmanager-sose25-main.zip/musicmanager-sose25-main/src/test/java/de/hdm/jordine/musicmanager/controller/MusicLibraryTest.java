package de.hdm.jordine.musicmanager.controller;

import de.hdm.jordine.musicmanager.model.ITrack;
import de.hdm.jordine.musicmanager.model.TrackFactory;
import de.hdm.jordine.musicmanager.model.TrackType;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Collection;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class MusicLibraryTest {

    @Autowired
    private MusicLibrary musicLibrary;

    @BeforeEach
    void setUp() {
        musicLibrary.clearLibrary();
        musicLibrary.addTrack("Test Title 1", "Test Artist 1", "test/path1.mp3");
        musicLibrary.addTrack("Test Title 2", "Test Artist 2", "test/path2.mp3");
    }

    @AfterEach
    void tearDown() {
        musicLibrary.clearLibrary();
    }

    @Test
    void testAddTrack() {
        musicLibrary.addTrack("Test Title 3", "Test Artist 3", "test/path3.mp3");
        ITrack track = musicLibrary.getTrack("Test Title 3");
        assertNotNull(track);
        assertEquals("Test Title 3", track.getTitle());
        assertEquals("Test Artist 3", track.getArtist());
        assertEquals("test/path3.mp3", track.getPath());
    }

    @Test
    void testGetTrack() {
        ITrack track = musicLibrary.getTrack("Test Title 1");
        assertNotNull(track);
        assertEquals("Test Title 1", track.getTitle());
        assertEquals("Test Artist 1", track.getArtist());
        assertEquals("test/path1.mp3", track.getPath());
    }

    @Test
    void testGetTrackNotFound() {
        assertThrows(IllegalArgumentException.class, () -> musicLibrary.getTrack("Nonexistent Title"));
    }

    @Test
    void testGetLibrary() {
        Collection<ITrack> tracks = musicLibrary.getLibrary();
        assertEquals(2, tracks.size());
    }

    @Test
    void testGetTrackById() {
        ITrack expected = musicLibrary.addTrack("Test Title 1", "Updated Artist", "updated/path.mp3");
        ITrack actual = musicLibrary.getTrack(expected.getDbId());
        assertNotNull(actual);
        assertEquals(expected.getDbId(), actual.getDbId());
    }

    @Test
    void testGetTrackByIdNotFound() {
        assertThrows(IllegalArgumentException.class, () -> musicLibrary.getTrack(999));
    }

    @Test
    void testUpdateTrack() {
        ITrack track = TrackFactory.createTrackInstance(TrackType.DEFAULT, "Test Title 1", "Updated Artist", "updated/path.mp3");
        track.setDbId(musicLibrary.getTrack("Test Title 1").getDbId());
        musicLibrary.updateTrack(track);
        ITrack updatedTrack = musicLibrary.getTrack("Test Title 1");
        assertEquals("Updated Artist", updatedTrack.getArtist());
        assertEquals("updated/path.mp3", updatedTrack.getPath());
    }

    @Test
    void testDeleteTrack() {
        ITrack track = musicLibrary.getTrack("Test Title 1");
        musicLibrary.deleteTrack(track);
        assertThrows(IllegalArgumentException.class, () -> musicLibrary.getTrack("Test Title 1"));

    }

    @Test
    void testGetRandomTrack() {
        ITrack track = musicLibrary.getRandomTrack();
        assertNotNull(track);
    }

    @Test
    void testGetRandomTrackEmptyLibrary() {
        musicLibrary.clearLibrary();
        assertThrows(IndexOutOfBoundsException.class, () -> musicLibrary.getRandomTrack());
    }
}