package de.hdm.jordine.musicmanager.db;


import de.hdm.jordine.musicmanager.model.ITrack;
import de.hdm.jordine.musicmanager.model.TrackFactory;
import de.hdm.jordine.musicmanager.model.TrackType;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class NoSqlManagerTest {

    private final String TEST_TITLE = "test_title";
    private final String TEST_ARTIST = "test_artist";
    private final String TEST_PATH = "test_path";

    private final String TEST_UPDATE_TITLE = "test_update_title";
    private final String TEST_UPDATE_ARTIST = "test_update_artist";
    private final String TEST_UPDATE_PATH = "test_update_path";

    @Test
    void getInstance() {
        assertNotEquals(null, NoSqlManager.getInstance());
    }

    @Test
    void insertAudioTrack() {
        ITrack track = TrackFactory.createTrackInstance(TrackType.DEFAULT, TEST_TITLE, TEST_ARTIST, TEST_PATH);

        assertEquals(0, track.getDbId());
        NoSqlManager.getInstance().insertAudioTrack(track);
        assertNotEquals(0, track.getDbId());

        NoSqlManager.getInstance().deleteAudioTrack(track);
    }

    @Test
    void getAudioTracks() {
        ITrack track = TrackFactory.createTrackInstance(TrackType.DEFAULT, TEST_TITLE, TEST_ARTIST, TEST_PATH);

        NoSqlManager.getInstance().insertAudioTrack(track);
        assertFalse(NoSqlManager.getInstance().getAudioTracks().isEmpty());

        NoSqlManager.getInstance().deleteAudioTrack(track);
    }

    @Test
    void getAudioTrack() {
        ITrack track = TrackFactory.createTrackInstance(TrackType.DEFAULT, TEST_TITLE, TEST_ARTIST, TEST_PATH);

        NoSqlManager.getInstance().insertAudioTrack(track);
        ITrack received = NoSqlManager.getInstance().getAudioTrack(track.getDbId());
        assertEquals(track.getDbId(), received.getDbId());

        NoSqlManager.getInstance().deleteAudioTrack(track);
    }

    @Test
    void updateAudioTrack() {
        ITrack track = TrackFactory.createTrackInstance(TrackType.DEFAULT, TEST_TITLE, TEST_ARTIST, TEST_PATH);

        NoSqlManager.getInstance().insertAudioTrack(track);

        ITrack updatedTrack = TrackFactory.createTrackInstance(TrackType.DEFAULT, TEST_UPDATE_TITLE,
                TEST_UPDATE_ARTIST, TEST_UPDATE_PATH);
        assertTrue(track.getDbId() > 0);
        updatedTrack.setDbId(track.getDbId());

        NoSqlManager.getInstance().updateAudioTrack(updatedTrack);

        ITrack received = NoSqlManager.getInstance().getAudioTrack(track.getDbId());

        assertEquals(TEST_UPDATE_TITLE, received.getTitle());
        assertEquals(TEST_UPDATE_ARTIST, received.getArtist());
        assertEquals(TEST_UPDATE_PATH, received.getPath());

        NoSqlManager.getInstance().deleteAudioTrack(track);
    }

    @Test
    void deleteAudioTrack() {
        ITrack track = TrackFactory.createTrackInstance(TrackType.DEFAULT, TEST_TITLE, TEST_ARTIST, TEST_PATH);

        NoSqlManager.getInstance().insertAudioTrack(track);

        NoSqlManager.getInstance().deleteAudioTrack(track);

        assertThrows(IllegalArgumentException.class, () -> NoSqlManager.getInstance().getAudioTrack(track.getDbId()));
    }


}
