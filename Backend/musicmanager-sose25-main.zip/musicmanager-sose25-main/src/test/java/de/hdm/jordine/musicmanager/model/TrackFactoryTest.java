package de.hdm.jordine.musicmanager.model;

import de.hdm.jordine.musicmanager.exception.InvalidTrackException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TrackFactoryTest {

    @Test
    void testCreateTrackInstanceDefault() {
        ITrack track = TrackFactory.createTrackInstance(TrackType.DEFAULT, "Test Title", "Test Artist", "test/path.mp3");
        assertNotNull(track);
        assertEquals("Test Title", track.getTitle());
        assertEquals("Test Artist", track.getArtist());
        assertEquals("test/path.mp3", track.getPath());
    }

    @Test
    void testCreateTrackInstanceInvalidType() {
        Exception exception = assertThrows(InvalidTrackException.class, () -> {
            TrackFactory.createTrackInstance(null, "Test Title", "Test Artist", "test/path.mp3");
        });
        assertEquals("Unknown track type: null", exception.getMessage());
    }
}