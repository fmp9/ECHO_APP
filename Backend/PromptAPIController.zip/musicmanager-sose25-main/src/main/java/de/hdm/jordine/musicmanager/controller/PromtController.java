package de.hdm.jordine.musicmanager.controller;

import de.hdm.jordine.musicmanager.model.Promt;
import org.springframework.stereotype.Service;

@Service
public class PromtController {

    public PromtController() {

    }

    public Promt getRandomPrompt(){
        return new Promt("Think about it", "How was your day?");
    }

}
